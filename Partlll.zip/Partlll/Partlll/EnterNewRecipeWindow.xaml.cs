﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using static Partlll.Dif;

namespace Partlll
{
    /// <summary>
    /// Interaction logic for EnterNewRecipeWindow.xaml
    /// </summary>
    
        public partial class EnterNewRecipeWindow : Window
        {
            public event EventHandler<RecipeEventArgs> RecipeAdded;

            public EnterNewRecipeWindow()
            {
                InitializeComponent();
            }

            private void AddIngredientsButton_Click(object sender, RoutedEventArgs e)
            {
                int numIngredients;
                if (int.TryParse(NumIngredientsTextBox.Text, out numIngredients))
                {
                    IngredientsPanel.Children.Clear();
                    for (int i = 0; i < numIngredients; i++)
                    {
                        StackPanel ingredientPanel = new StackPanel { Margin = new Thickness(0, 5, 0, 5) };
                        ingredientPanel.Children.Add(new TextBlock { Text = $"Ingredient {i + 1}:" });
                        ingredientPanel.Children.Add(new TextBox { Name = $"IngredientName{i}", Margin = new Thickness(0, 2, 0, 2), Tag = $"IngredientName{i}", Text = "Name" });
                        ingredientPanel.Children.Add(new TextBox { Name = $"IngredientQuantity{i}", Margin = new Thickness(0, 2, 0, 2), Tag = $"IngredientQuantity{i}", Text = "Quantity" });
                        ingredientPanel.Children.Add(new TextBox { Name = $"IngredientUnit{i}", Margin = new Thickness(0, 2, 0, 2), Tag = $"IngredientUnit{i}",Text = "Unit" });
                        ingredientPanel.Children.Add(new TextBox { Name = $"IngredientCalories{i}", Margin = new Thickness(0, 2, 0, 2), Tag = $"IngredientCalories{i}",Text = "Calories" });
                        ingredientPanel.Children.Add(new TextBox { Name = $"IngredientFoodGroup{i}", Margin = new Thickness(0, 2, 0, 2), Tag = $"IngredientFoodGroup{i}", Text = "Food Group" });
                        IngredientsPanel.Children.Add(ingredientPanel);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid number for ingredients.");
                }
            }

            private void AddStepsButton_Click(object sender, RoutedEventArgs e)
            {
                int numSteps;
                if (int.TryParse(NumStepsTextBox.Text, out numSteps))
                {
                    StepsPanel.Children.Clear();
                    for (int i = 0; i < numSteps; i++)
                    {
                        StackPanel stepPanel = new StackPanel { Margin = new Thickness(0, 5, 0, 5) };
                        stepPanel.Children.Add(new TextBlock { Text = $"Step {i + 1}:" });
                        stepPanel.Children.Add(new TextBox { Name = $"StepDescription{i}", Margin = new Thickness(0, 2, 0, 2), Tag = $"StepDescription{i}", Text = "Description" });
                        StepsPanel.Children.Add(stepPanel);
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid number for steps.");
                }
            }

            private void SubmitRecipeButton_Click(object sender, RoutedEventArgs e)
            {
                string name = RecipeNameTextBox.Text;
                if (string.IsNullOrWhiteSpace(name))
                {
                    MessageBox.Show("Recipe name cannot be empty.");
                    return;
                }

                Recipe recipe = new Recipe(name);

                foreach (StackPanel panel in IngredientsPanel.Children)
                {
                    string ingredientName = ((TextBox)panel.Children[1]).Text;
                    double quantity = double.Parse(((TextBox)panel.Children[2]).Text);
                    string unit = ((TextBox)panel.Children[3]).Text;
                    int calories = int.Parse(((TextBox)panel.Children[4]).Text);
                    string foodGroup = ((TextBox)panel.Children[5]).Text;

                    recipe.AddIngredient(ingredientName, quantity, unit, calories, foodGroup);
                }

                foreach (StackPanel panel in StepsPanel.Children)
                {
                    string description = ((TextBox)panel.Children[1]).Text;
                    recipe.AddStep(description);
                }

                RecipeAdded?.Invoke(this, new RecipeEventArgs(recipe));
                MessageBox.Show("Recipe added successfully!");
                this.Close();
            }
        }
    }
