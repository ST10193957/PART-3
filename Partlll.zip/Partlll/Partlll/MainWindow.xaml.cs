﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using static Partlll.Dif;

namespace Partlll
{
    public partial class MainWindow : Window
    {
        static List<Recipe> recipes = new List<Recipe>();
        static event RecipeCaloriesNotification NotifyCaloriesExceed;

        public MainWindow()
        {
            InitializeComponent();
            NotifyCaloriesExceed += NotifyCaloriesExceedHandler;
        }

        private void EnterRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            RecipeEntryPanel.Visibility = Visibility.Visible;
        }

        private void DisplayAllRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            DisplayAllRecipesPanel.Visibility = Visibility.Visible;
            RecipesListView.ItemsSource = recipes;
        }

        private void DisplayRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            HideAllPanels();
            DisplayRecipePanel.Visibility = Visibility.Visible;
            SingleRecipeListView.ItemsSource = recipes;
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void AddIngredientsButton_Click(object sender, RoutedEventArgs e)
        {
            int numIngredients;
            if (int.TryParse(NumIngredientsTextBox.Text, out numIngredients))
            {
                IngredientsPanel.Children.Clear();
                for (int i = 0; i < numIngredients; i++)
                {
                    StackPanel ingredientPanel = new StackPanel { Margin = new Thickness(0, 5, 0, 5) };
                    ingredientPanel.Children.Add(new TextBlock { Text = $"Ingredient {i + 1}:" });
                    ingredientPanel.Children.Add(new TextBox { Name = $"IngredientName{i}", Margin = new Thickness(0, 2, 0, 2), Text = "Name" });
                    ingredientPanel.Children.Add(new TextBox { Name = $"IngredientQuantity{i}", Margin = new Thickness(0, 2, 0, 2), Text = "Quantity" });
                    ingredientPanel.Children.Add(new TextBox { Name = $"IngredientUnit{i}", Margin = new Thickness(0, 2, 0, 2), Text = "Unit" });
                    ingredientPanel.Children.Add(new TextBox { Name = $"IngredientCalories{i}", Margin = new Thickness(0, 2, 0, 2), Text = "Calories" });
                    ingredientPanel.Children.Add(new TextBox { Name = $"IngredientFoodGroup{i}", Margin = new Thickness(0, 2, 0, 2), Text = "Food Group" });
                    IngredientsPanel.Children.Add(ingredientPanel);
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number for ingredients.");
            }
        }

        private void AddStepsButton_Click(object sender, RoutedEventArgs e)
        {
            int numSteps;
            if (int.TryParse(NumStepsTextBox.Text, out numSteps))
            {
                StepsPanel.Children.Clear();
                for (int i = 0; i < numSteps; i++)
                {
                    StackPanel stepPanel = new StackPanel { Margin = new Thickness(0, 5, 0, 5) };
                    stepPanel.Children.Add(new TextBlock { Text = $"Step {i + 1}:" });
                    stepPanel.Children.Add(new TextBox { Name = $"StepDescription{i}", Margin = new Thickness(0, 2, 0, 2), Text = "Description" });
                    StepsPanel.Children.Add(stepPanel);
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number for steps.");
            }
        }

        private void SubmitRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string name = RecipeNameTextBox.Text;
            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Recipe name cannot be empty.");
                return;
            }

            Recipe recipe = new Recipe(name);

            foreach (StackPanel panel in IngredientsPanel.Children)
            {
                string ingredientName = ((TextBox)panel.Children[1]).Text;
                double quantity = double.Parse(((TextBox)panel.Children[2]).Text);
                string unit = ((TextBox)panel.Children[3]).Text;
                int calories = int.Parse(((TextBox)panel.Children[4]).Text);
                string foodGroup = ((TextBox)panel.Children[5]).Text;

                recipe.AddIngredient(ingredientName, quantity, unit, calories, foodGroup);
            }

            foreach (StackPanel panel in StepsPanel.Children)
            {
                string description = ((TextBox)panel.Children[1]).Text;
                recipe.AddStep(description);
            }

            recipes.Add(recipe);
            int totalCalories = recipe.TotalCalories();
            if (totalCalories > 300)
            {
                NotifyCaloriesExceed(name, totalCalories);
            }

            MessageBox.Show("Recipe added successfully!");
            RecipeEntryPanel.Visibility = Visibility.Collapsed;
        }

        private void ShowRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            Recipe selectedRecipe = (Recipe)SingleRecipeListView.SelectedItem;
            if (selectedRecipe != null)
            {
                MessageBox.Show($"Recipe: {selectedRecipe.Name}\n\n" +
                                $"Ingredients:\n" +
                                $"{string.Join("\n", selectedRecipe.Ingredients.Select(ing => $"{ing.Quantity} {ing.Unit} of {ing.Name}"))}\n\n" +
                                $"Steps:\n" +
                                $"{string.Join("\n", selectedRecipe.Steps.Select((step, index) => $"{index + 1}. {step.Description}"))}");
            }
            else
            {
                MessageBox.Show("Please select a recipe.");
            }
        }

        private void HideAllPanels()
        {
            RecipeEntryPanel.Visibility = Visibility.Collapsed;
            DisplayAllRecipesPanel.Visibility = Visibility.Collapsed;
            DisplayRecipePanel.Visibility = Visibility.Collapsed;
        }

        private void NotifyCaloriesExceedHandler(string recipeName, int totalCalories)
        {
            MessageBox.Show($"Warning: The total calories of recipe '{recipeName}' exceed 300. Total calories: {totalCalories}");
        }
    }

    public class Recipe
    {
        public string Name { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<Step> Steps { get; set; }

        public Recipe(string name)
        {
            Name = name;
            Ingredients = new List<Ingredient>();
            Steps = new List<Step>();
        }

        public void AddIngredient(string name, double quantity, string unit, int calories, string foodGroup)
        {
            Ingredients.Add(new Ingredient { Name = name, Quantity = quantity, Unit = unit, Calories = calories, FoodGroup = foodGroup });
        }

        public void AddStep(string description)
        {
            Steps.Add(new Step { Description = description });
        }

        public int TotalCalories()
        {
            return Ingredients.Sum(ingredient => ingredient.Calories);
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public int Calories { get; set; }
        public string FoodGroup { get; set; }
    }

    public class Step
    {
        public string Description { get; set; }
    }

    public class RecipeEventArgs : EventArgs
    {
        public Recipe Recipe { get; set; }

        public RecipeEventArgs(Recipe recipe)
        {
            Recipe = recipe;
        }
    }

    public delegate void RecipeCaloriesNotification(string recipeName, int totalCalories);
}
